package com.library.concreateclass;

import java.util.ArrayList;
import java.util.List;


import com.library.factoryinterface.searchInterface;
import com.library.model.Book;

public class Horror implements searchInterface {

	@Override
	public void search(String catagory) {
		// TODO Auto-generated method stub
		System.out.println("search For Horror");
		
		 List<Book> bookList1 =new ArrayList<>();
		    Book b1=new Book(1, "XYZ","Horror");
			Book b2=new Book(2, "ABC","Drama");
			Book b3=new Book(3, "LMN","Adventure");
			bookList1.add(b1);
			bookList1.add(b2);
			bookList1.add(b3);
			
			bookList1.stream().filter(n->n.getCatagory()==catagory).forEach(System.out::println);
			//bookList1.forEach(s->System.out.print(s + " "));
	}

}
