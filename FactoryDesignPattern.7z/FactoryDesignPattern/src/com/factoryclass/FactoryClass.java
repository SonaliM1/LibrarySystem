package com.factoryclass;

import java.util.Scanner;

import com.library.factoryinterface.searchInterface;

public class FactoryClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SearchCatagoryFactory sf=new SearchCatagoryFactory();
		
		System.out.println("Enter the Book Catagory for search");
		Scanner scan=new Scanner(System.in);
		String catogory=scan.nextLine();
		
		if(catogory.equalsIgnoreCase("Horror")){
			searchInterface search1=sf.getsearch("Horror");
			search1.search("Horror");
		}else if (catogory.equalsIgnoreCase("Drama")) {
			
			searchInterface search2=sf.getsearch("Drama");
			search2.search("Drama");
		}else if (catogory.equalsIgnoreCase("Adventure")) {
			
			searchInterface search3=sf.getsearch("Adventure");
			search3.search("Adventure");
		}
		else {
			System.out.println("Search Book Not available ..");
		}
	
	}

}
